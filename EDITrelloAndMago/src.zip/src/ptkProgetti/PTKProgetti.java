package ptkProgetti;

import java.util.HashMap;


public class PTKProgetti {

	private HashMap<String, PTKProgetto> progetti = new HashMap<String, PTKProgetto>(); 
	
	public PTKProgetti() {
		 
	}
	
	public HashMap<String, PTKProgetto> getProgetti() {
		return progetti;
	}
	
	
}
